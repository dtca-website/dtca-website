DTCA WEBSITE
=============
Files:
- index.html : complete responsive website

How to use:
1. Open index.html in any browser to preview.
2. Upload index.html to any static hosting service.
3. The admission form opens WhatsApp to 0311-6444009.

Replace/update text, images, logo, courses or fee inside index.html as needed.
